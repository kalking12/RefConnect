import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { validateReferralEligibility, validateReferralProcedure } from "../shared/referral";
import { PROCEDURE_SPECIALTIES, SURGERY_TYPES } from "../shared/readiness";
import type { TrpcContext } from "./_core/context";

function contextFor(role: "user" | "admin"): TrpcContext {
  return {
    user: { id: 42, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("administrator data access", () => {
  it("rejects capability updates from a regular user before a data write occurs", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.updateCapabilities({ hospitalId: "akth", capabilities: { electricity: 2 } })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("referral validation", () => {
  it("requires an active stored profile and active destination facility", () => {
    expect(() => validateReferralEligibility(null, { id: 1, active: true })).toThrow("pre-registered patient profile");
    expect(() => validateReferralEligibility({ id: "profile-1", active: true }, { id: 1, active: false })).toThrow("active destination hospital");
    expect(() => validateReferralEligibility({ id: "profile-1", active: true }, { id: 1, active: true })).not.toThrow();
  });

  it("rejects malformed referral requests before attempting a handoff", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.showcase.createReferral({ profileId: "", destinationHospitalId: "akth", surgeryTypeId: "cancer-surgery" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("accepts a selectable active procedure from every specialty and rejects retired procedure identifiers", () => {
    PROCEDURE_SPECIALTIES.forEach((specialty) => {
      const procedure = SURGERY_TYPES.find((item) => item.specialty === specialty);
      expect(procedure).toBeDefined();
      expect(() => validateReferralProcedure({ id: procedure!.id, active: true })).not.toThrow();
    });
    expect(() => validateReferralProcedure({ id: "lung-transplant", active: false })).toThrow("active procedure");
  });
});
