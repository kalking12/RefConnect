import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createReferral, listHospitalReadiness, listPatientProfiles, updateHospitalCapabilities, updateHospitalProfile } from "./db";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access is required." });
  return next();
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  showcase: router({
    hospitals: publicProcedure.query(() => listHospitalReadiness()),
    profiles: publicProcedure.query(() => listPatientProfiles()),
    createReferral: publicProcedure.input(z.object({
      profileId: z.string().min(1), destinationHospitalId: z.string().min(1), surgeryTypeId: z.string().min(1),
    })).mutation(({ input }) => createReferral(input.profileId, input.destinationHospitalId, input.surgeryTypeId)),
  }),
  admin: router({
    updateCapabilities: adminProcedure.input(z.object({
      hospitalId: z.string().min(1),
      capabilities: z.record(z.string(), z.number().int().min(0).max(2)),
    })).mutation(({ input }) => updateHospitalCapabilities(input.hospitalId, input.capabilities)),
    updateHospitalProfile: adminProcedure.input(z.object({
      hospitalId: z.string().min(1), grade: z.number().int().min(1).max(5), facilityLevel: z.string().min(2).max(128),
      ownership: z.string().min(2).max(128), description: z.string().min(10).max(2000),
    })).mutation(({ input }) => updateHospitalProfile(input.hospitalId, input)),
  }),
});

export type AppRouter = typeof appRouter;
