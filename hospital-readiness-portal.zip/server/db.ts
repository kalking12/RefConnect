import { count, eq, inArray, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { nanoid } from "nanoid";
import { ACTIVE_SHOWCASE_HOSPITALS, INACTIVE_SHOWCASE_HOSPITALS, SHOWCASE_PROFILE } from "../shared/showcaseData";
import { calculateReadiness, type CapabilityKey, type CapabilityLevel, type CapabilityValues, SURGERY_TYPES } from "../shared/readiness";
import { validateReferralEligibility, validateReferralProcedure } from "../shared/referral";
import { hospitalCapabilities, hospitals, type InsertUser, patientProfiles, referralHandoffs, surgeryCriteria, surgeryTypes, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export type HospitalReadinessView = {
  id: string;
  name: string;
  shortName: string | null;
  ownership: string;
  facilityLevel: string;
  grade: number | null;
  lga: string;
  ward: string | null;
  description: string | null;
  active: boolean;
  sourceNote: string | null;
  isIllustrative: boolean;
  capabilities: CapabilityValues;
  scores: Record<string, number>;
};

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export function resolveUserUpsertRole(user: Pick<InsertUser, "openId" | "role">) {
  const role = user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : "user");
  return {
    role,
    shouldUpdateExistingRole: user.role !== undefined || user.openId === ENV.ownerOpenId,
  };
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  (["name", "email", "loginMethod"] as const).forEach((field) => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  const roleResolution = resolveUserUpsertRole(user);
  values.role = roleResolution.role;
  if (roleResolution.shouldUpdateExistingRole) updateSet.role = values.role;
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function scoresFor(capabilities: CapabilityValues) {
  return Object.fromEntries(SURGERY_TYPES.map((surgery) => [surgery.id, calculateReadiness(capabilities, surgery.weights)]));
}

function staticHospitalViews(): HospitalReadinessView[] {
  return [
    ...ACTIVE_SHOWCASE_HOSPITALS.map((hospital) => ({
      id: hospital.id,
      name: hospital.name,
      shortName: hospital.shortName,
      ownership: hospital.ownership,
      facilityLevel: hospital.facilityLevel,
      grade: hospital.grade,
      lga: hospital.lga,
      ward: hospital.ward,
      description: hospital.description,
      active: true,
      sourceNote: hospital.sourceNote,
      isIllustrative: true,
      capabilities: hospital.capabilities,
      scores: scoresFor(hospital.capabilities),
    })),
    ...INACTIVE_SHOWCASE_HOSPITALS.map((hospital) => ({
      id: hospital.id,
      name: hospital.name,
      shortName: null,
      ownership: hospital.ownership,
      facilityLevel: hospital.facilityLevel,
      grade: null,
      lga: hospital.lga,
      ward: hospital.ward,
      description: null,
      active: false,
      sourceNote: "Kano State facility directory record — inactive showcase listing.",
      isIllustrative: false,
      capabilities: {},
      scores: {},
    })),
  ];
}

export async function ensureShowcaseData() {
  const db = await getDb();
  if (!db) return false;
  const existing = await db.select({ total: count() }).from(hospitals);
  const hasHospitalData = (existing[0]?.total ?? 0) > 0;

  if (!hasHospitalData) {
  await db.insert(hospitals).values([
    ...ACTIVE_SHOWCASE_HOSPITALS.map((hospital) => ({
      externalId: hospital.id,
      name: hospital.name,
      shortName: hospital.shortName,
      ownership: hospital.ownership,
      facilityLevel: hospital.facilityLevel,
      grade: hospital.grade,
      lga: hospital.lga,
      ward: hospital.ward,
      latitude: hospital.latitude,
      longitude: hospital.longitude,
      description: hospital.description,
      active: true,
      sourceNote: hospital.sourceNote,
      isIllustrative: true,
    })),
    ...INACTIVE_SHOWCASE_HOSPITALS.map((hospital) => ({
      externalId: hospital.id,
      name: hospital.name,
      shortName: null,
      ownership: hospital.ownership,
      facilityLevel: hospital.facilityLevel,
      grade: null,
      lga: hospital.lga,
      ward: hospital.ward,
      latitude: hospital.latitude,
      longitude: hospital.longitude,
      description: null,
      active: false,
      sourceNote: "Kano State facility directory record — inactive showcase listing.",
      isIllustrative: false,
    })),
  ]);

  const inserted = await db.select().from(hospitals);
  const idByExternal = new Map(inserted.map((hospital) => [hospital.externalId, hospital.id]));
  const capabilityRows = ACTIVE_SHOWCASE_HOSPITALS.flatMap((hospital) => Object.entries(hospital.capabilities).map(([capabilityKey, level]) => ({
    hospitalId: idByExternal.get(hospital.id)!,
    capabilityKey,
    level,
  })));
  await db.insert(hospitalCapabilities).values(capabilityRows);
  await db.insert(patientProfiles).values({
    id: SHOWCASE_PROFILE.id,
    displayName: SHOWCASE_PROFILE.displayName,
    patientReference: SHOWCASE_PROFILE.patientReference,
    conditionSummary: SHOWCASE_PROFILE.conditionSummary,
    sourceHospitalId: idByExternal.get(SHOWCASE_PROFILE.sourceHospitalId),
    isDemonstration: true,
    active: true,
  });
  }

  await db.insert(surgeryTypes).values(SURGERY_TYPES.map((surgery) => ({
    externalId: surgery.id, name: surgery.name, shortName: surgery.shortName, specialty: surgery.specialty, description: surgery.description, active: true,
  }))).onDuplicateKeyUpdate({ set: {
    name: sql`VALUES(${surgeryTypes.name})`,
    shortName: sql`VALUES(${surgeryTypes.shortName})`,
    specialty: sql`VALUES(${surgeryTypes.specialty})`,
    description: sql`VALUES(${surgeryTypes.description})`,
    active: true,
  } });
  await db.update(surgeryTypes).set({ active: false }).where(inArray(surgeryTypes.externalId, ["cancer-surgery", "cardiac-surgery", "lung-transplant", "orthopaedic-surgery"]));
  const allHospitalRows = await db.select().from(hospitals);
  const hospitalIdByExternal = new Map(allHospitalRows.map((hospital) => [hospital.externalId, hospital.id]));
  const currentCapabilities = await db.select().from(hospitalCapabilities);
  const capabilityKeys = new Set(currentCapabilities.map((row) => `${row.hospitalId}:${row.capabilityKey}`));
  const missingCapabilities = ACTIVE_SHOWCASE_HOSPITALS.flatMap((hospital) => Object.entries(hospital.capabilities).map(([capabilityKey, level]) => ({
    hospitalId: hospitalIdByExternal.get(hospital.id)!, capabilityKey, level,
  }))).filter((row) => !capabilityKeys.has(`${row.hospitalId}:${row.capabilityKey}`));
  if (missingCapabilities.length) await db.insert(hospitalCapabilities).values(missingCapabilities);

  const insertedSurgeryTypes = await db.select().from(surgeryTypes);
  const idBySurgery = new Map(insertedSurgeryTypes.map((surgery) => [surgery.externalId, surgery.id]));
  const criteriaRows = SURGERY_TYPES.flatMap((surgery) => Object.entries(surgery.weights).map(([capabilityKey, weight]) => ({
    surgeryTypeId: idBySurgery.get(surgery.id)!, capabilityKey, weight,
  })));
  await db.insert(surgeryCriteria).values(criteriaRows).onDuplicateKeyUpdate({ set: { weight: sql`VALUES(${surgeryCriteria.weight})` } });
  return true;
}

export async function listHospitalReadiness(): Promise<HospitalReadinessView[]> {
  const db = await getDb();
  if (!db) return staticHospitalViews();
  await ensureShowcaseData();
  const hospitalRows = await db.select().from(hospitals);
  const capabilityRows = await db.select().from(hospitalCapabilities);
  const capsByHospital = new Map<number, CapabilityValues>();
  for (const row of capabilityRows) {
    const existing = capsByHospital.get(row.hospitalId) ?? {};
    existing[row.capabilityKey as CapabilityKey] = row.level as CapabilityLevel;
    capsByHospital.set(row.hospitalId, existing);
  }
  return hospitalRows.map((hospital) => {
    const capabilities = capsByHospital.get(hospital.id) ?? {};
    return {
      id: hospital.externalId,
      name: hospital.name,
      shortName: hospital.shortName,
      ownership: hospital.ownership,
      facilityLevel: hospital.facilityLevel,
      grade: hospital.grade,
      lga: hospital.lga,
      ward: hospital.ward,
      description: hospital.description,
      active: hospital.active,
      sourceNote: hospital.sourceNote,
      isIllustrative: hospital.isIllustrative,
      capabilities,
      scores: hospital.active ? scoresFor(capabilities) : {},
    };
  });
}

export async function updateHospitalCapabilities(externalId: string, capabilities: CapabilityValues) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable. Capability changes cannot be saved.");
  await ensureShowcaseData();
  const hospital = (await db.select().from(hospitals).where(eq(hospitals.externalId, externalId)).limit(1))[0];
  if (!hospital?.active) throw new Error("Only active showcase hospitals can be updated.");
  for (const [capabilityKey, level] of Object.entries(capabilities)) {
    await db.insert(hospitalCapabilities).values({ hospitalId: hospital.id, capabilityKey, level: level ?? 0 }).onDuplicateKeyUpdate({ set: { level: level ?? 0 } });
  }
  return listHospitalReadiness();
}

export async function updateHospitalProfile(externalId: string, input: { grade: number; facilityLevel: string; ownership: string; description: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable. Hospital profile changes cannot be saved.");
  await ensureShowcaseData();
  const hospital = (await db.select().from(hospitals).where(eq(hospitals.externalId, externalId)).limit(1))[0];
  if (!hospital?.active) throw new Error("Only active showcase hospitals can be updated.");
  await db.update(hospitals).set({ grade: input.grade, facilityLevel: input.facilityLevel, ownership: input.ownership, description: input.description }).where(eq(hospitals.id, hospital.id));
  return listHospitalReadiness();
}

export async function listPatientProfiles() {
  const db = await getDb();
  if (!db) return [SHOWCASE_PROFILE];
  await ensureShowcaseData();
  const rows = await db.select().from(patientProfiles).where(eq(patientProfiles.active, true));
  return rows.map((profile) => ({
    id: profile.id,
    displayName: profile.displayName,
    patientReference: profile.patientReference,
    conditionSummary: profile.conditionSummary,
    isDemonstration: profile.isDemonstration,
  }));
}

export async function createReferral(profileId: string, destinationExternalId: string, surgeryTypeId: string) {
  const db = await getDb();
  if (!db) return { id: `demo-${Date.now()}`, status: "prepared" as const };
  await ensureShowcaseData();
  const profile = (await db.select().from(patientProfiles).where(eq(patientProfiles.id, profileId)).limit(1))[0];
  const destination = (await db.select().from(hospitals).where(eq(hospitals.externalId, destinationExternalId)).limit(1))[0];
  const procedure = (await db.select().from(surgeryTypes).where(eq(surgeryTypes.externalId, surgeryTypeId)).limit(1))[0];
  validateReferralEligibility(profile, destination);
  validateReferralProcedure(procedure && { id: procedure.externalId, active: procedure.active });
  const id = nanoid();
  await db.insert(referralHandoffs).values({
    id,
    profileId: profile.id,
    sourceHospitalId: profile.sourceHospitalId,
    destinationHospitalId: destination.id,
    surgeryTypeId,
    profileSnapshot: JSON.stringify({ displayName: profile.displayName, patientReference: profile.patientReference, conditionSummary: profile.conditionSummary, sourceHospitalId: profile.sourceHospitalId }),
    status: "prepared",
  });
  return { id, status: "prepared" as const };
}
