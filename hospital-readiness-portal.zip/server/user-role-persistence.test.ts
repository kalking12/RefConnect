import { describe, expect, it } from "vitest";
import { resolveUserUpsertRole } from "./db";

describe("user role persistence", () => {
  it("does not overwrite an existing assigned role during a normal sign-in update", () => {
    expect(resolveUserUpsertRole({ openId: "ordinary-user" })).toEqual({
      role: "user",
      shouldUpdateExistingRole: false,
    });
  });

  it("allows an explicit administrator assignment to be persisted", () => {
    expect(resolveUserUpsertRole({ openId: "ordinary-user", role: "admin" })).toEqual({
      role: "admin",
      shouldUpdateExistingRole: true,
    });
  });
});
