export type ReferralProfileStatus = { id: string; active: boolean } | null | undefined;
export type ReferralDestinationStatus = { id: number; active: boolean } | null | undefined;
export type ActiveProcedureStatus = { id: string; active: boolean } | null | undefined;

/** Keeps referral creation from proceeding without an active stored profile and active receiving facility. */
export function validateReferralEligibility(profile: ReferralProfileStatus, destination: ReferralDestinationStatus) {
  if (!profile?.active) throw new Error("A valid pre-registered patient profile is required.");
  if (!destination?.active) throw new Error("An active destination hospital is required.");
}

/** Prevents a referral handoff from carrying a retired or unknown procedure identifier. */
export function validateReferralProcedure(procedure: ActiveProcedureStatus) {
  if (!procedure?.active) throw new Error("A valid active procedure is required for referral.");
}
