import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { CAPABILITY_DEFINITIONS, capabilityLabel, readinessTier, SURGERY_TYPES } from "@shared/readiness";
import { CheckCircle2, Database, LockKeyhole, RefreshCw, Save, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

type Hospital = { id: string; name: string; shortName: string | null; ownership: string; facilityLevel: string; grade: number | null; description: string | null; active: boolean; capabilities: Record<string, number>; scores: Record<string, number> };

const levelStyle: Record<number, string> = { 0: "border-rose-200 bg-rose-50 text-rose-700", 1: "border-amber-200 bg-amber-50 text-amber-700", 2: "border-emerald-200 bg-emerald-50 text-emerald-700" };
const hospitalLabel = (hospital: Pick<Hospital, "name" | "shortName">) => hospital.shortName ? `${hospital.name} (${hospital.shortName})` : hospital.name;

function AdminBody() {
  const { user } = useAuth();
  const hospitalsQuery = trpc.showcase.hospitals.useQuery();
  const updateCapabilities = trpc.admin.updateCapabilities.useMutation();
  const updateProfile = trpc.admin.updateHospitalProfile.useMutation();
  const utils = trpc.useUtils();
  const activeHospitals = ((hospitalsQuery.data ?? []) as Hospital[]).filter((hospital) => hospital.active);
  const [drafts, setDrafts] = useState<Record<string, Record<string, number>>>({});
  const [selectedHospitalId, setSelectedHospitalId] = useState("");
  const [profileDraft, setProfileDraft] = useState({ grade: "", facilityLevel: "", ownership: "", description: "" });

  useEffect(() => {
    if (!activeHospitals.length) return;
    setDrafts((previous) => Object.keys(previous).length ? previous : Object.fromEntries(activeHospitals.map((hospital) => [hospital.id, hospital.capabilities])));
    setSelectedHospitalId((previous) => previous || activeHospitals[0].id);
  }, [activeHospitals]);

  const selectedHospital = activeHospitals.find((hospital) => hospital.id === selectedHospitalId) ?? activeHospitals[0];
  useEffect(() => {
    if (!selectedHospital) return;
    setProfileDraft({ grade: String(selectedHospital.grade ?? 3), facilityLevel: selectedHospital.facilityLevel, ownership: selectedHospital.ownership, description: selectedHospital.description ?? "" });
  }, [selectedHospital?.id, selectedHospital?.grade, selectedHospital?.facilityLevel, selectedHospital?.ownership, selectedHospital?.description]);

  const changedHospitalIds = useMemo(() => activeHospitals.filter((hospital) => JSON.stringify(drafts[hospital.id] ?? {}) !== JSON.stringify(hospital.capabilities)).map((hospital) => hospital.id), [activeHospitals, drafts]);
  const cycleLevel = (hospitalId: string, capabilityKey: string) => setDrafts((previous) => ({ ...previous, [hospitalId]: { ...(previous[hospitalId] ?? {}), [capabilityKey]: (((previous[hospitalId] ?? {})[capabilityKey] ?? 0) + 1) % 3 } }));
  const saveLedger = async () => {
    try {
      await Promise.all(changedHospitalIds.map((hospitalId) => updateCapabilities.mutateAsync({ hospitalId, capabilities: drafts[hospitalId] ?? {} })));
      await utils.showcase.hospitals.invalidate();
      toast.success(`${changedHospitalIds.length} hospital capability record${changedHospitalIds.length === 1 ? "" : "s"} saved.`);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Capability updates could not be saved."); }
  };
  const saveProfile = async () => {
    if (!selectedHospital) return;
    try {
      await updateProfile.mutateAsync({ hospitalId: selectedHospital.id, grade: Number(profileDraft.grade), facilityLevel: profileDraft.facilityLevel, ownership: profileDraft.ownership, description: profileDraft.description });
      await utils.showcase.hospitals.invalidate();
      toast.success(`${hospitalLabel(selectedHospital)} profile saved.`);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Hospital profile could not be saved."); }
  };

  if (user?.role !== "admin") return <div className="mx-auto flex min-h-[70vh] max-w-xl flex-col items-center justify-center px-6 text-center"><LockKeyhole className="h-9 w-9 text-[#b17924]" /><h1 className="mt-5 font-display text-3xl text-[#173d36]">Administrator access required</h1><p className="mt-3 text-sm leading-6 text-[#617d74]">Only assigned administrators can update hospital capability records and institutional profiles.</p><Link href="/#doctor-portal" className="mt-6 rounded-full bg-[#0b746b] px-5 py-2.5 text-xs font-bold text-white">Return to Doctor Portal</Link></div>;
  if (hospitalsQuery.isLoading) return <div className="p-4 md:p-8"><div className="h-12 w-56 animate-pulse rounded-xl bg-[#e4eee9]" /><div className="mt-7 h-[520px] animate-pulse rounded-2xl bg-[#e8f1ed]" /></div>;

  return <div className="mx-auto max-w-[1560px] p-1 md:p-5"><div className="mb-7 flex flex-col justify-between gap-5 lg:flex-row lg:items-end"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-[#1b9780]">Protected administrator workspace</p><h1 className="mt-2 font-display text-[34px] tracking-[-0.025em] text-[#173d36]">Admin portal</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-[#637c74]">Each cell is a structured capability level. Readiness scores are calculated server-side from the latest saved values and reflected in the doctor portal.</p></div><div className="flex items-center gap-2"><Link href="/#doctor-portal" className="rounded-full border border-[#ccdfd8] bg-white px-4 py-2 text-xs font-bold text-[#38675d] hover:bg-[#f4faf7]">View doctor portal</Link><Button onClick={saveLedger} disabled={!changedHospitalIds.length || updateCapabilities.isPending} className="rounded-full bg-[#0b746b] px-4 text-xs font-bold hover:bg-[#075d57]"><Save className="mr-1.5 h-3.5 w-3.5" />Save {changedHospitalIds.length ? `${changedHospitalIds.length} update${changedHospitalIds.length > 1 ? "s" : ""}` : "updates"}</Button></div></div>
    <div className="mb-6 grid gap-3 md:grid-cols-2"><div className="rounded-xl border border-[#cfe2db] bg-[#eef8f3] p-4"><ShieldCheck className="h-4 w-4 text-[#0b746b]" /><p className="mt-3 text-xs font-bold text-[#28594d]">Illustrative showcase data</p><p className="mt-1 text-[11px] leading-5 text-[#5f7c73]">All five active baselines are clearly marked and designed for demonstration only.</p></div><div className="rounded-xl border border-[#d7e4de] bg-white p-4"><Database className="h-4 w-4 text-[#3e8192]" /><p className="mt-3 text-xs font-bold text-[#2f5d66]">Backend scoring enabled</p><p className="mt-1 text-[11px] leading-5 text-[#5f7c73]">Twenty-two weighted capability factors are recalculated automatically by procedure.</p></div></div>
    <section className="surface-shadow overflow-hidden rounded-2xl border border-[#d7e4df] bg-white"><div className="flex items-center justify-between border-b border-[#e6eeeb] px-5 py-4"><div><h2 className="font-display text-xl text-[#1c4038]">Capability matrix</h2><p className="mt-1 text-[11px] text-[#6c867e]">Click a value to cycle: unavailable → limited → available.</p></div><button onClick={() => hospitalsQuery.refetch()} className="inline-flex items-center gap-1.5 text-xs font-bold text-[#3b7468] hover:text-[#0b746b]"><RefreshCw className="h-3.5 w-3.5" />Refresh</button></div><div className="overflow-auto"><table className="min-w-[1320px] w-full border-collapse text-left"><thead className="bg-[#f2f7f5]"><tr><th className="sticky left-0 z-20 min-w-[250px] border-b border-r border-[#dde9e5] bg-[#f2f7f5] px-5 py-4 font-mono text-[10px] uppercase tracking-[0.14em] text-[#587a71]">Capability factor</th>{activeHospitals.map((hospital) => <th key={hospital.id} className="min-w-[210px] border-b border-[#dde9e5] px-4 py-4"><p className="text-xs font-bold leading-5 text-[#244940]">{hospitalLabel(hospital)}</p><p className="mt-1 text-[10px] font-normal text-[#789188]">{hospital.grade ? `Grade ${hospital.grade}` : hospital.facilityLevel}</p></th>)}</tr></thead><tbody>{CAPABILITY_DEFINITIONS.map((capability, rowIndex) => <tr key={capability.key} className={rowIndex % 2 ? "bg-[#fbfdfc]" : "bg-white"}><td className={`sticky left-0 z-10 border-b border-r border-[#edf2ef] px-5 py-3 ${rowIndex % 2 ? "bg-[#fbfdfc]" : "bg-white"}`}><p className="text-xs font-bold text-[#31584e]">{capability.label}</p><p className="mt-0.5 font-mono text-[9px] uppercase tracking-wider text-[#8aa099]">{capability.group}</p></td>{activeHospitals.map((hospital) => { const value = drafts[hospital.id]?.[capability.key] ?? hospital.capabilities[capability.key] ?? 0; return <td key={hospital.id} className="border-b border-[#edf2ef] px-4 py-3"><button onClick={() => cycleLevel(hospital.id, capability.key)} className={`min-w-[100px] rounded-full border px-3 py-1.5 text-[11px] font-bold ${levelStyle[value]}`} title="Cycle capability level">{capabilityLabel(value)}</button></td>; })}</tr>)}</tbody></table></div></section>
    <section className="mt-6 grid gap-6 xl:grid-cols-[.8fr_1.2fr]"><div className="surface-shadow rounded-2xl border border-[#d7e4df] bg-white p-5"><p className="font-mono text-[10px] font-bold uppercase tracking-[0.17em] text-[#0b746b]">Live score output</p><h2 className="mt-2 font-display text-2xl text-[#1c4038]">Procedure readiness</h2><div className="mt-5 space-y-3">{SURGERY_TYPES.map((surgery) => <div key={surgery.id} className="rounded-xl border border-[#e6eeeb] p-3"><p className="text-xs font-bold text-[#31584e]">{surgery.name}</p><div className="mt-3 grid grid-cols-5 gap-1.5">{activeHospitals.map((hospital) => { const score = hospital.scores[surgery.id] ?? 0; const tier = readinessTier(score); const color = tier.tone === "ready" ? "text-emerald-700" : tier.tone === "conditional" ? "text-amber-700" : "text-rose-700"; return <div key={hospital.id} className="rounded-lg bg-[#f5f9f7] px-2 py-2 text-center"><p className="font-mono text-[9px] text-[#6d8780]">{hospital.shortName}</p><p className={`mt-1 text-xs font-bold ${color}`}>{score}%</p></div>; })}</div></div>)}</div></div>
      <div className="surface-shadow rounded-2xl border border-[#d7e4df] bg-white p-5"><div className="flex flex-wrap items-end justify-between gap-3"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[0.17em] text-[#0b746b]">Institution profile</p><h2 className="mt-2 font-display text-2xl text-[#1c4038]">Editable clinical context</h2></div><select value={selectedHospitalId} onChange={(event) => setSelectedHospitalId(event.target.value)} className="h-9 rounded-lg border border-[#d4e3dd] bg-white px-3 text-xs font-bold text-[#356057]">{activeHospitals.map((hospital) => <option key={hospital.id} value={hospital.id}>{hospitalLabel(hospital)}</option>)}</select></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><label className="text-xs font-bold text-[#42675d]">Resource grade<Input type="number" min="1" max="5" value={profileDraft.grade} onChange={(event) => setProfileDraft((current) => ({ ...current, grade: event.target.value }))} className="mt-2 border-[#d5e4de]" /></label><label className="text-xs font-bold text-[#42675d]">Care level<Input value={profileDraft.facilityLevel} onChange={(event) => setProfileDraft((current) => ({ ...current, facilityLevel: event.target.value }))} className="mt-2 border-[#d5e4de]" /></label><label className="text-xs font-bold text-[#42675d] sm:col-span-2">Ownership<Input value={profileDraft.ownership} onChange={(event) => setProfileDraft((current) => ({ ...current, ownership: event.target.value }))} className="mt-2 border-[#d5e4de]" /></label><label className="text-xs font-bold text-[#42675d] sm:col-span-2">Institutional description<Textarea value={profileDraft.description} onChange={(event) => setProfileDraft((current) => ({ ...current, description: event.target.value }))} className="mt-2 min-h-28 border-[#d5e4de] text-xs leading-5" /></label></div><div className="mt-4 flex justify-end"><Button onClick={saveProfile} disabled={updateProfile.isPending} className="rounded-full bg-[#173d36] px-4 text-xs font-bold hover:bg-[#0b746b]"><Save className="mr-1.5 h-3.5 w-3.5" />Save institution profile</Button></div></div></section>
  </div>;
}

export default function AdminPortal() { return <DashboardLayout><AdminBody /></DashboardLayout>; }
