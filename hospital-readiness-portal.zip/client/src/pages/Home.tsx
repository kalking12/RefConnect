import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { PortalSwitcher } from "@/components/PortalSwitcher";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { CAPABILITY_DEFINITIONS, PROCEDURE_SPECIALTIES, readinessTier, SURGERY_TYPES } from "@shared/readiness";
import { Activity, ArrowRight, Building2, Check, CircleAlert, ClipboardCheck, Globe2, HeartPulse, Mail, MapPin, MessageCircleMore, Network, Phone, Search, ShieldCheck, SlidersHorizontal, Stethoscope, Users, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

type Hospital = {
  id: string; name: string; shortName: string | null; ownership: string; facilityLevel: string; grade: number | null;
  lga: string; ward: string | null; description: string | null; active: boolean; sourceNote: string | null;
  isIllustrative: boolean; capabilities: Record<string, number>; scores: Record<string, number>;
};

type PatientProfile = { id: string; displayName: string; patientReference: string; conditionSummary: string; isDemonstration: boolean };

const tierStyles = {
  ready: "bg-emerald-50 text-emerald-700 ring-emerald-600/15",
  conditional: "bg-amber-50 text-amber-700 ring-amber-600/15",
  "not-ready": "bg-rose-50 text-rose-700 ring-rose-600/15",
};

const PORTAL_IMAGES = {
  logo: "/manus-storage/refconnect-logo_5ff04615.jpeg",
  publicHeader: "/manus-storage/surgical-team-green-background_fb989ce6.jpg",
  adminCallout: "/manus-storage/operating-theatre-background_ca93d1be.jpg",
  procedureFinder: "/manus-storage/procedure-finder-clinician_e277aa28.png",
};

function ReadinessRing({ score, size = 76 }: { score: number; size?: number }) {
  const tier = readinessTier(score);
  const color = tier.tone === "ready" ? "#0b8d61" : tier.tone === "conditional" ? "#c07a16" : "#cc4a3c";
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const dash = (score / 100) * circumference;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} aria-label={`${score}% readiness`}>
      <svg viewBox="0 0 96 96" className="h-full w-full -rotate-90">
        <circle cx="48" cy="48" r={radius} fill="none" stroke="#e8efec" strokeWidth="8" />
        <circle cx="48" cy="48" r={radius} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round" strokeDasharray={`${dash} ${circumference - dash}`} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center"><span className="font-mono text-[15px] font-medium text-[#1d3a35]">{score}</span><span className="font-mono -mt-1 text-[8px] text-[#719087]">%</span></div>
    </div>
  );
}

function CapabilityDots({ capability, level }: { capability: string; level: number }) {
  const item = CAPABILITY_DEFINITIONS.find((entry) => entry.key === capability);
  if (!item) return null;
  const tone = level === 2 ? "bg-emerald-500" : level === 1 ? "bg-amber-400" : "bg-rose-400";
  return <span className="inline-flex items-center gap-1.5 text-[11px] text-[#59726b]"><span className={`h-1.5 w-1.5 rounded-full ${tone}`} /><span>{item.label}</span></span>;
}

function HospitalCard({ hospital, surgeryId, rank, compared, onCompare, onRefer }: { hospital: Hospital; surgeryId: string; rank: number; compared: boolean; onCompare: () => void; onRefer: () => void }) {
  const score = hospital.scores[surgeryId] ?? 0;
  const tier = readinessTier(score);
  const capabilities = Object.entries(hospital.capabilities).filter(([, level]) => level > 0).slice(0, 3);
  return (
    <article className="surface-shadow flex flex-col gap-5 rounded-[1.35rem] border border-[#dfe9e5] bg-white p-5 transition-shadow hover:shadow-[0_18px_44px_-26px_rgba(13,60,51,0.38)] md:flex-row md:items-start">
      <ReadinessRing score={score} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="mb-2 flex flex-wrap items-center gap-2"><span className="font-mono text-[10px] uppercase tracking-[0.15em] text-[#558178]">Rank {rank} · {hospital.shortName ?? hospital.facilityLevel}</span>{hospital.isIllustrative && <span className="rounded-full bg-[#f4f0e7] px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-[#887347]">Showcase baseline</span>}</div>
            <h3 className="font-display text-[22px] leading-tight text-[#173d36]">{hospital.name}{hospital.shortName ? ` (${hospital.shortName})` : ""}</h3>
            <p className="mt-1 text-xs text-[#6b857e]">{hospital.ownership} · {hospital.grade ? `Grade ${hospital.grade}` : hospital.facilityLevel}</p>
          </div>
          <span className={`inline-flex w-fit items-center rounded-full px-3 py-1 text-xs font-bold ring-1 ${tierStyles[tier.tone]}`}>{tier.label}</span>
        </div>
        <p className="mt-3 line-clamp-2 text-[12px] leading-5 text-[#5c746d]">{hospital.description}</p>
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2">{capabilities.map(([key, level]) => <CapabilityDots key={key} capability={key} level={level} />)}</div>
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <Button onClick={onRefer} className="h-9 rounded-full bg-[#0b746b] px-4 text-xs font-bold hover:bg-[#075d57]">Refer profile <ArrowRight className="ml-1.5 h-3.5 w-3.5" /></Button>
          <Button variant="outline" onClick={onCompare} className={`h-9 rounded-full border-[#cfe0da] px-4 text-xs font-bold ${compared ? "bg-[#e2f0eb] text-[#0c6c5d]" : "text-[#37655b]"}`}>{compared ? <Check className="mr-1.5 h-3.5 w-3.5" /> : <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" />}{compared ? "Selected" : "Compare"}</Button>
          <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-[#748b85]"><MapPin className="h-3.5 w-3.5" />{hospital.lga}</span>
        </div>
      </div>
    </article>
  );
}

function ComparisonBar({ hospitals, surgeryId, onRemove }: { hospitals: Hospital[]; surgeryId: string; onRemove: (id: string) => void }) {
  if (!hospitals.length) return null;
  const surgery = SURGERY_TYPES.find((entry) => entry.id === surgeryId) ?? SURGERY_TYPES[0];
  const criteria = Object.entries(surgery.weights);

  return (
    <section className="surface-shadow sticky top-[74px] z-20 mb-7 rounded-2xl border border-[#c9dfd7] bg-[#f7fcfa] p-4 md:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div><p className="font-mono text-[10px] font-bold uppercase tracking-[0.17em] text-[#0b746b]">Comparison tray</p><h2 className="mt-1 font-display text-xl text-[#173d36]">Up to three active hospitals</h2></div>
        <span className="text-xs text-[#688279]">{hospitals.length} of 3 selected</span>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        {hospitals.map((hospital) => {
          const score = hospital.scores[surgeryId] ?? 0;
          const tier = readinessTier(score);
          return <div key={hospital.id} className="rounded-xl bg-white p-3 ring-1 ring-[#e3ece8]"><div className="flex items-start justify-between gap-2"><div><p className="text-xs font-bold text-[#244840]">{hospital.name}{hospital.shortName ? ` (${hospital.shortName})` : ""}</p></div><button onClick={() => onRemove(hospital.id)} className="rounded-full p-1 text-[#7b938b] hover:bg-[#edf5f1]" aria-label={`Remove ${hospital.name} from comparison`}><X className="h-3.5 w-3.5" /></button></div><div className="mt-3 flex items-center gap-3"><span className="font-mono text-xl text-[#173d36]">{score}%</span><Progress value={score} className="h-1.5 flex-1 bg-[#e9f0ed] [&>div]:bg-[#0b8d61]" /></div><p className={`mt-2 text-[10px] font-bold ${tier.tone === "ready" ? "text-emerald-700" : tier.tone === "conditional" ? "text-amber-700" : "text-rose-700"}`}>{tier.label}</p></div>;
        })}
      </div>
      <div className="mt-5 overflow-x-auto rounded-xl border border-[#dfeae5] bg-white">
        <div className="min-w-[620px] divide-y divide-[#edf2ef] text-[11px]">
          <div className="grid grid-cols-[1.4fr_repeat(3,minmax(120px,1fr))] bg-[#f0f7f4] px-3 py-2 font-mono text-[9px] font-bold uppercase tracking-[0.12em] text-[#52776c]"><span>Weighted requirement</span>{[0, 1, 2].map((index) => <span key={index}>{hospitals[index]?.shortName ?? ""}</span>)}</div>
          {criteria.map(([capabilityKey, weight]) => {
            const label = CAPABILITY_DEFINITIONS.find((entry) => entry.key === capabilityKey)?.label ?? capabilityKey;
            return <div key={capabilityKey} className="grid grid-cols-[1.4fr_repeat(3,minmax(120px,1fr))] px-3 py-2.5"><span className="font-medium text-[#365f54]">{label} <span className="ml-1 font-mono text-[9px] text-[#8b9d97]">{weight}% wt</span></span>{[0, 1, 2].map((index) => { const level = hospitals[index]?.capabilities[capabilityKey]; const label = level === 2 ? "Available" : level === 1 ? "Limited" : level === 0 ? "Unavailable" : "—"; const tone = level === 2 ? "text-emerald-700" : level === 1 ? "text-amber-700" : level === 0 ? "text-rose-700" : "text-[#9caea7]"; return <span key={index} className={`font-semibold ${tone}`}>{label}</span>; })}</div>;
          })}
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  const hospitalsQuery = trpc.showcase.hospitals.useQuery();
  const profilesQuery = trpc.showcase.profiles.useQuery();
  const referralMutation = trpc.showcase.createReferral.useMutation();
  const [selectedSurgery, setSelectedSurgery] = useState<string>(SURGERY_TYPES[0].id);
  const [selectedSpecialty, setSelectedSpecialty] = useState(SURGERY_TYPES[0].specialty);
  const [procedureSearch, setProcedureSearch] = useState("");
  const [openSpecialties, setOpenSpecialties] = useState<string[]>([SURGERY_TYPES[0].specialty]);
  const [comparisonIds, setComparisonIds] = useState<string[]>([]);
  const [referralHospital, setReferralHospital] = useState<Hospital | null>(null);

  const hospitals = (hospitalsQuery.data ?? []) as Hospital[];
  const activeHospitals = hospitals.filter((hospital) => hospital.active);
  const inactiveHospitals = hospitals.filter((hospital) => !hospital.active);
  const profile = (profilesQuery.data?.[0] ?? null) as PatientProfile | null;
  const compared = useMemo(() => activeHospitals.filter((hospital) => comparisonIds.includes(hospital.id)), [activeHospitals, comparisonIds]);
  const surgery = SURGERY_TYPES.find((entry) => entry.id === selectedSurgery) ?? SURGERY_TYPES[0];
  const normalizedSearch = procedureSearch.trim().toLowerCase();
  const proceduresBySpecialty = useMemo(() => PROCEDURE_SPECIALTIES.map((specialty) => ({
    specialty,
    procedures: SURGERY_TYPES.filter((procedure) => procedure.specialty === specialty && (!normalizedSearch || `${procedure.name} ${procedure.shortName} ${procedure.description} ${procedure.specialty}`.toLowerCase().includes(normalizedSearch))),
  })).filter((group) => group.procedures.length), [normalizedSearch]);
  const rankedHospitals = useMemo(() => [...activeHospitals].sort((a, b) => (b.scores[selectedSurgery] ?? 0) - (a.scores[selectedSurgery] ?? 0)), [activeHospitals, selectedSurgery]);

  useEffect(() => {
    if (normalizedSearch) setOpenSpecialties(proceduresBySpecialty.map((group) => group.specialty));
  }, [normalizedSearch, proceduresBySpecialty]);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const revealTargets = ["about", "services", "contact"].map((id) => document.getElementById(id)).filter((element): element is HTMLElement => Boolean(element));
    const liftTargets = document.querySelectorAll<HTMLElement>("#about article, #services article");
    document.documentElement.classList.add("motion-ready");
    revealTargets.forEach((element) => element.classList.add("scroll-reveal"));
    liftTargets.forEach((element) => element.classList.add("motion-lift"));
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-revealed");
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -42px" });
    revealTargets.forEach((element) => observer.observe(element));
    return () => {
      observer.disconnect();
      document.documentElement.classList.remove("motion-ready");
      revealTargets.forEach((element) => element.classList.remove("scroll-reveal", "is-revealed"));
      liftTargets.forEach((element) => element.classList.remove("motion-lift"));
    };
  }, []);

  const chooseProcedure = (procedureId: string) => {
    const procedure = SURGERY_TYPES.find((item) => item.id === procedureId);
    if (!procedure) return;
    setSelectedSurgery(procedure.id);
    setSelectedSpecialty(procedure.specialty);
    setOpenSpecialties((current) => current.includes(procedure.specialty) ? current : [...current, procedure.specialty]);
  };

  const toggleCompare = (id: string) => {
    setComparisonIds((current) => {
      if (current.includes(id)) return current.filter((selected) => selected !== id);
      if (current.length >= 3) { toast.info("You can compare up to three hospitals at a time."); return current; }
      return [...current, id];
    });
  };

  const completeReferral = async () => {
    if (!profile || !referralHospital) return;
    try {
      await referralMutation.mutateAsync({ profileId: profile.id, destinationHospitalId: referralHospital.id, surgeryTypeId: selectedSurgery });
      toast.success(`Referral package prepared for ${referralHospital.shortName ?? referralHospital.name}.`);
      setReferralHospital(null);
    } catch (error) { toast.error(error instanceof Error ? error.message : "The referral could not be prepared."); }
  };

  return <div className="min-h-screen overflow-x-hidden bg-[#f6faf8] text-[#173d36]">
    <header className="sticky top-0 z-30 border-b border-[#dfe9e5]/80 bg-[#f6faf8]/90"><div className="container flex h-[74px] items-center justify-between"><a href="#overview" className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-xl border border-[#c7d8d2] bg-white shadow-[0_8px_18px_-8px_rgba(11,116,107,.42)]"><img src={PORTAL_IMAGES.logo} alt="RefConnect logo" width="36" height="36" decoding="async" className="h-full w-full object-cover object-center scale-[1.45]" /></span><span><span className="block font-display text-[17px] leading-none">RefConnect</span><span className="mt-1 block font-mono text-[8px] font-bold uppercase tracking-[0.17em] text-[#59827a]">Universal referral network</span></span></a><nav className="hidden items-center gap-6 text-xs font-bold text-[#45675e] lg:flex"><a href="#about" className="hover:text-[#0b746b]">About RefConnect</a><a href="#doctor-portal" className="hover:text-[#0b746b]">Doctor portal</a><a href="#services" className="hover:text-[#0b746b]">Services</a></nav><div className="flex items-center gap-2"><a href="#doctor-portal" className="inline-flex rounded-full border border-[#c8ddd7] bg-white px-3 py-2 text-xs font-bold text-[#2c5d52] hover:bg-[#f4faf7] sm:px-4">Doctor portal</a><Link href="/admin" className="inline-flex rounded-full bg-[#0b746b] px-3 py-2 text-xs font-bold text-white hover:bg-[#075d57] sm:px-4">Administrator portal <ArrowRight className="ml-1.5 hidden h-3.5 w-3.5 sm:block" /></Link></div></div></header>

    <PortalSwitcher />
    <div className="fixed bottom-4 right-4 z-50"><ThemeToggle /></div>
    <main>
      <section id="overview" className="mesh-bg noise-grid relative isolate overflow-hidden border-b border-[#e0ebe7]"><img src={PORTAL_IMAGES.publicHeader} alt="" aria-hidden="true" width="2560" height="1440" decoding="async" fetchPriority="high" className="absolute inset-0 -z-20 h-full w-full object-cover object-center opacity-45" /><div aria-hidden="true" className="hero-photo-scrim absolute inset-0 -z-10" /><div className="container py-14 lg:py-20"><div className="enter-rise max-w-3xl"><div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#c7e0d7] bg-[#dff1e9] px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.15em] text-[#137064]"><ShieldCheck className="h-3.5 w-3.5" /> Capability-led referral decisions</div><h1 className="font-display text-[42px] leading-[0.98] tracking-[-0.035em] text-[#173d36] sm:text-[58px]">Clearer pathways for <em className="font-normal text-[#0b746b]">complex care.</em></h1><p className="mt-6 max-w-2xl text-[15px] leading-7 text-[#46695f]">Compare hospital readiness by procedure, understand the resource factors behind each score and prepare a pre-registered referral handoff with confidence.</p></div></div></section>

      <section id="about" className="border-b border-[#dde9e5] bg-white"><div className="container py-12 lg:py-16"><div className="grid gap-8 lg:grid-cols-[.88fr_1.12fr]"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[.17em] text-[#0b746b]">Nigeria’s first digital referral platform</p><h2 className="mt-3 max-w-xl font-display text-[35px] leading-tight tracking-[-.025em] text-[#173d36]">One coordinated path from clinical decision to confirmed referral.</h2><p className="mt-4 max-w-xl text-sm leading-7 text-[#617b73]">RefConnect is the foremost referral coordination system for healthcare in Nigeria. It helps providers use real-time hospital information to confirm resource availability, book referrals, and move patients without wasting time, money, or lives.</p><a href="#doctor-portal" className="mt-6 inline-flex items-center text-xs font-bold text-[#0b746b] hover:text-[#075d57]">Explore the Doctor Portal <ArrowRight className="ml-2 h-3.5 w-3.5" /></a></div><div className="grid gap-4 sm:grid-cols-2"><article className="rounded-2xl border border-[#d9e8e2] bg-[#f5faf7] p-5"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#dff1e9] text-[#0b746b]"><Activity className="h-4.5 w-4.5" /></span><p className="mt-5 font-mono text-[10px] font-bold uppercase tracking-[.15em] text-[#62837a]">Mission</p><p className="mt-2 text-sm font-bold leading-6 text-[#244b41]">To provide coordinated and reliable referral services for healthcare centres in Nigeria.</p></article><article className="rounded-2xl border border-[#d9e8e2] bg-[#f5faf7] p-5"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#dff1e9] text-[#0b746b]"><Globe2 className="h-4.5 w-4.5" /></span><p className="mt-5 font-mono text-[10px] font-bold uppercase tracking-[.15em] text-[#62837a]">Vision</p><p className="mt-2 text-sm font-bold leading-6 text-[#244b41]">To be the leading platform for healthcare referral in Africa.</p></article><article className="rounded-2xl border border-[#d9e8e2] bg-[#173d36] p-5 text-[#e9f5f0] sm:col-span-2"><div className="flex flex-col gap-4 sm:flex-row sm:items-start"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#9cd1c1]"><Network className="h-4.5 w-4.5" /></span><div><p className="font-mono text-[10px] font-bold uppercase tracking-[.15em] text-[#9cd1c1]">What we do</p><p className="mt-2 text-sm leading-6 text-[#d2e6de]">We facilitate digital referrals between healthcare centres, coordinating and monitoring the referral process with real-time data so providers can confirm capability and connect patients to the right destination.</p></div></div></article></div></div></div></section>

      <section id="doctor-portal" className="container py-12 lg:py-16"><div><div className="inline-flex items-center gap-2 rounded-full bg-[#e9f5f1] px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-[#0b746b]"><Stethoscope className="h-3.5 w-3.5" /> Doctor portal</div><h2 className="mt-3 font-display text-[34px] tracking-[-0.025em] text-[#173d36]">Find a procedure. Choose the best-ready destination.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-[#617b73]">Search for any medical procedure.</p></div>
        <div className="mt-8 grid gap-5 xl:grid-cols-[360px_minmax(0,1fr)]"><aside className="surface-shadow rounded-2xl border border-[#d8e7e1] bg-white p-4 md:p-5"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-[#0b746b]">Best fit hospital</p><h3 className="mt-2 font-display text-2xl text-[#173d36]">Search a surgery</h3></div><div className="relative mt-4"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6b867d]" /><Input value={procedureSearch} onChange={(event) => setProcedureSearch(event.target.value)} placeholder="e.g. CABG, Whipple, hip..." className="h-11 border-[#cedfd8] bg-[#fbfdfc] pl-10 text-sm" aria-label="Search procedures" /></div><p className="mt-3 text-[11px] leading-5 text-[#708a82]">{normalizedSearch ? `${proceduresBySpecialty.reduce((count, group) => count + group.procedures.length, 0)} matching procedures` : `${SURGERY_TYPES.length} procedure pathways across ${PROCEDURE_SPECIALTIES.length} specialties`}</p><Accordion type="multiple" value={openSpecialties} onValueChange={setOpenSpecialties} className="mt-4 border-t border-[#e4eeea]">{proceduresBySpecialty.map(({ specialty, procedures }) => <AccordionItem key={specialty} value={specialty} className="border-b-[#e4eeea]"><AccordionTrigger className="py-3 text-left text-xs font-bold text-[#2d584d] hover:no-underline"><span>{specialty}</span><span className="mr-2 rounded-full bg-[#edf6f2] px-2 py-0.5 font-mono text-[9px] text-[#568076]">{procedures.length}</span></AccordionTrigger><AccordionContent className="pb-3"><div className="space-y-1">{procedures.map((procedure) => <button key={procedure.id} onClick={() => chooseProcedure(procedure.id)} className={`w-full rounded-lg px-3 py-2 text-left text-[11px] leading-4 transition-colors ${selectedSurgery === procedure.id ? "bg-[#0b746b] font-bold text-white" : "text-[#54746a] hover:bg-[#eff7f3] hover:text-[#173d36]"}`}><span className="block">{procedure.name}</span><span className={`mt-0.5 block font-mono text-[9px] ${selectedSurgery === procedure.id ? "text-white/75" : "text-[#80978f]"}`}>{procedure.shortName}</span></button>)}</div></AccordionContent></AccordionItem>)}</Accordion>{proceduresBySpecialty.length > 0 && <figure className="relative mt-4 overflow-hidden rounded-xl border border-[#dce9e4] bg-[#e6f0ec]"><img src={PORTAL_IMAGES.procedureFinder} alt="Clinician discussing a referral plan with a patient" width="612" height="408" loading="lazy" decoding="async" className="h-36 w-full object-cover object-center" /><figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#123b33]/90 via-[#123b33]/35 to-transparent px-3 pt-8 text-[10px] font-semibold leading-4 text-white">A clearer procedure search supports a more confident referral conversation.</figcaption></figure>}{!proceduresBySpecialty.length && <div className="mt-4 rounded-xl bg-[#f5f8f7] p-4 text-center text-xs text-[#657e76]">No procedure matches “{procedureSearch}”. Try a procedure name, acronym, or specialty.</div>}</aside><div className="surface-shadow rounded-2xl border border-[#d8e7e1] bg-white p-5 md:p-6"><p className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-[#0b746b]">Selected procedure · {surgery.specialty}</p><h3 className="mt-2 font-display text-[30px] leading-tight text-[#173d36]">{surgery.name}</h3><p className="mt-3 max-w-2xl text-sm leading-6 text-[#647d75]">{surgery.description} This pathway uses a normalized 22-factor readiness profile.</p><div className="mt-6 rounded-xl border border-[#dbe9e4] bg-[#f7fbf9] p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold text-[#28564a]">Referral destinations, ranked by readiness</p><p className="mt-1 text-[11px] text-[#668078]">Choose a hospital to compare resource factors or prepare the pre-registered referral.</p></div><span className="rounded-full bg-[#e2f2ec] px-2.5 py-1 font-mono text-[10px] font-bold text-[#0b746b]">{rankedHospitals.length} active</span></div><div className="mt-4 grid gap-2 sm:grid-cols-2">{rankedHospitals.map((hospital, index) => { const score = hospital.scores[selectedSurgery] ?? 0; const tier = readinessTier(score); return <button key={hospital.id} onClick={() => setReferralHospital(hospital)} className="flex items-center gap-3 rounded-xl border border-[#dbe7e2] bg-white p-3 text-left transition hover:border-[#82b8aa] hover:shadow-sm"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#edf6f2] font-mono text-xs font-bold text-[#0b746b]">{index + 1}</span><span className="min-w-0 flex-1"><span className="block truncate text-xs font-bold text-[#254e44]">{hospital.shortName ?? hospital.name}</span><span className="mt-0.5 block text-[10px] text-[#70877f]">{tier.label}</span></span><span className="font-mono text-lg font-medium text-[#173d36]">{score}%</span></button>; })}</div></div></div></div>
        <ComparisonBar hospitals={compared} surgeryId={selectedSurgery} onRemove={(id) => setComparisonIds((current) => current.filter((item) => item !== id))} />
        <div className="mt-7 grid gap-4 xl:grid-cols-2">{hospitalsQuery.isLoading ? Array.from({ length: 4 }).map((_, index) => <div key={index} className="h-64 animate-pulse rounded-2xl bg-[#e8f1ed]" />) : rankedHospitals.map((hospital, index) => <HospitalCard key={hospital.id} hospital={hospital} surgeryId={selectedSurgery} rank={index + 1} compared={comparisonIds.includes(hospital.id)} onCompare={() => toggleCompare(hospital.id)} onRefer={() => setReferralHospital(hospital)} />)}</div>
      </section>

      <section id="network" className="border-y border-[#dde9e5] bg-[#edf5f1]">
        <div className="container py-12 lg:py-16">
          <div className="grid gap-7 lg:grid-cols-[.7fr_1.3fr]">
            <div>
              <p className="font-mono text-[10px] font-bold uppercase tracking-[0.17em] text-[#6b857d]">Network scale</p>
              <h2 className="mt-2 font-display text-[32px] leading-tight text-[#274c43]">A wider directory, awaiting connection.</h2>
              <p className="mt-4 text-sm leading-6 text-[#657e76]">The facilities below are a deterministic sample from the supplied Kano directory. They are intentionally inactive, greyed out and cannot receive comparisons or referrals until onboarding is complete.</p>
              <div className="mt-6 inline-flex items-start gap-2 rounded-xl bg-white/70 p-3 text-[11px] leading-5 text-[#6d807a]">
                <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-[#af832a]" />
                Directory listings do not imply surgical service availability.
              </div>
            </div>
            <div className="surface-shadow max-h-[480px] overflow-auto rounded-2xl border border-[#d6e4de] bg-white p-2">
              <div className="grid sm:grid-cols-2">
                {inactiveHospitals.map((hospital) => (
                  <div key={hospital.id} className="flex items-center gap-3 border-b border-[#edf2f0] p-3 opacity-55 grayscale last:border-b-0">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#edf1ef] text-[#9baca6]"><Building2 className="h-4 w-4" /></span>
                    <div className="min-w-0"><p className="truncate text-xs font-bold text-[#57736a]">{hospital.name}</p><p className="mt-0.5 text-[10px] text-[#84958f]">{hospital.facilityLevel} · {hospital.lga}</p></div>
                    <span className="ml-auto rounded-full bg-[#f1f3f2] px-2 py-1 font-mono text-[8px] font-bold uppercase tracking-wider text-[#9aaaa4]">Inactive</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="container py-12 lg:py-16"><div className="grid gap-8 lg:grid-cols-[.8fr_1.2fr]"><div><p className="font-mono text-[10px] font-bold uppercase tracking-[.17em] text-[#0b746b]">Connected referral services</p><h2 className="mt-3 font-display text-[34px] leading-tight tracking-[-.025em] text-[#173d36]">Built for the clinicians who make referral decisions.</h2><p className="mt-4 max-w-xl text-sm leading-7 text-[#617b73]">RefConnect gives healthcare providers and medical professionals one unified place to create, send, receive, coordinate, and monitor patient referral requests.</p><div className="mt-6 rounded-2xl border border-[#d8e7e1] bg-[#f6faf8] p-5"><div className="flex gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#dff1e9] text-[#0b746b]"><MessageCircleMore className="h-4.5 w-4.5" /></span><div><p className="text-sm font-bold text-[#254e44]">Doctor-to-doctor connection</p><p className="mt-1 text-xs leading-5 text-[#678077]">A single platform that supports provider communication, relationship building, and professional networking around referrals.</p></div></div></div></div><div className="grid gap-3 sm:grid-cols-2"><article className="rounded-2xl border border-[#d8e7e1] bg-white p-5"><Network className="h-5 w-5 text-[#0b746b]" /><h3 className="mt-5 text-sm font-bold text-[#254e44]">Electronic record integration</h3><p className="mt-2 text-xs leading-5 text-[#6b837a]">Integrating the electronic records of hospitals in Kano State to make referral decisions more informed.</p></article><article className="rounded-2xl border border-[#d8e7e1] bg-white p-5"><Building2 className="h-5 w-5 text-[#0b746b]" /><h3 className="mt-5 text-sm font-bold text-[#254e44]">One connected care network</h3><p className="mt-2 text-xs leading-5 text-[#6b837a]">Connecting primary, secondary, and tertiary healthcare centres through a single referral platform.</p></article><article className="rounded-2xl border border-[#d8e7e1] bg-white p-5"><MessageCircleMore className="h-5 w-5 text-[#0b746b]" /><h3 className="mt-5 text-sm font-bold text-[#254e44]">Referral communication</h3><p className="mt-2 text-xs leading-5 text-[#6b837a]">Facilitating faster communication between hospitals regarding patient referrals and resource availability.</p></article><article className="rounded-2xl border border-[#d8e7e1] bg-white p-5"><HeartPulse className="h-5 w-5 text-[#0b746b]" /><h3 className="mt-5 text-sm font-bold text-[#254e44]">Lives and resources protected</h3><p className="mt-2 text-xs leading-5 text-[#6b837a]">Saving lives and resources through a proper, coordinated referral database and clearer care pathways.</p></article></div></div></section>

      <section className="container py-10"><div className="relative isolate overflow-hidden rounded-2xl border border-[#cce0d8] bg-[#173d36] p-6 text-[#e9f5f0] md:flex md:items-center md:justify-between md:p-8"><img src={PORTAL_IMAGES.adminCallout} alt="Clinical team in an operating theatre" width="2560" height="1440" loading="lazy" decoding="async" className="absolute inset-0 -z-20 h-full w-full object-cover object-center opacity-50" /><div aria-hidden="true" className="absolute inset-0 -z-10 bg-[#123d36]/88" /><div><p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-[#b7e0d3]">For administrators</p><h2 className="mt-2 font-display text-2xl">Keep the referral picture current.</h2><p className="mt-2 max-w-xl text-sm leading-6 text-[#d7e9e3]">Update capability levels, resource grades and institutional descriptions in the protected ledger. Patient-facing scores respond to the latest saved data.</p></div><Button onClick={() => startLogin()} className="mt-5 rounded-full bg-[#e4f5ef] px-5 text-xs font-bold text-[#16443a] hover:bg-white md:mt-0">Sign in to manage data <ArrowRight className="ml-2 h-3.5 w-3.5" /></Button></div></section>

      <footer id="contact" className="border-t border-[#dce8e3] bg-[#edf5f1]"><div className="container py-10"><div className="grid gap-8 lg:grid-cols-[1.1fr_.9fr]"><div><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-xl border border-[#c7d8d2] bg-white"><img src={PORTAL_IMAGES.logo} alt="RefConnect logo" width="36" height="36" loading="lazy" decoding="async" className="h-full w-full object-cover object-center scale-[1.45]" /></span><div><p className="font-display text-lg text-[#173d36]">RefConnect</p><p className="font-mono text-[8px] font-bold uppercase tracking-[.17em] text-[#59827a]">Universal referral network</p></div></div><p className="mt-4 max-w-xl text-sm leading-6 text-[#617b73]">Coordinated and reliable digital referrals for healthcare centres in Nigeria, with a vision to lead healthcare referral across Africa.</p><p className="mt-6 text-[11px] text-[#728a82]">Copyright © ref-connect.com. All rights reserved · Terms and conditions · Privacy policies</p></div><div className="rounded-2xl border border-[#d4e3dd] bg-white p-5"><p className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-[#0b746b]">Contact us</p><div className="mt-4 grid gap-3 text-xs text-[#42665d]"><div className="flex items-start gap-2"><Phone className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#0b746b]" /><div className="flex flex-wrap gap-x-3 gap-y-1 leading-5"><a href="tel:+2348080047449" className="hover:text-[#0b746b]">+234 808 004 7449</a><a href="tel:+2348020646210" className="hover:text-[#0b746b]">+234 802 064 6210</a><a href="tel:+2348130515349" className="hover:text-[#0b746b]">+234 813 051 5349</a><a href="tel:+2348110349859" className="hover:text-[#0b746b]">+234 811 034 9859</a><a href="tel:+2347061706659" className="hover:text-[#0b746b]">+234 706 170 6659</a><a href="tel:+2349032884983" className="hover:text-[#0b746b]">+234 903 288 4983</a></div></div><a href="mailto:refconnectkano@gmail.com" className="flex items-center gap-2 hover:text-[#0b746b]"><Mail className="h-3.5 w-3.5 text-[#0b746b]" />refconnectkano@gmail.com</a><a href="https://www.refconnect.com" target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#0b746b]"><Globe2 className="h-3.5 w-3.5 text-[#0b746b]" />www.refconnect.com</a></div></div></div></div></footer>
    </main>

    <Dialog open={!!referralHospital} onOpenChange={(open) => !open && setReferralHospital(null)}><DialogContent className="max-w-md border-[#d7e5df] bg-[#fbfdfc]"><DialogHeader><p className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-[#0b746b]">Referral handoff</p><DialogTitle className="font-display text-2xl text-[#173d36]">Prepare referral to {referralHospital?.shortName ?? referralHospital?.name}</DialogTitle><DialogDescription className="pt-2 text-sm leading-6 text-[#607b73]">The selected pre-registered profile will be linked to this procedure and destination hospital. No manual data entry is needed here.</DialogDescription></DialogHeader>{profile ? <div className="space-y-4"><div className="rounded-xl border border-[#d8e7e1] bg-white p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-bold text-[#244b41]">{profile.displayName}</p><p className="mt-1 font-mono text-[10px] text-[#6a827a]">{profile.patientReference}</p></div><span className="rounded-full bg-[#f6eedb] px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-[#937238]">Demo profile</span></div><p className="mt-3 text-xs leading-5 text-[#607a72]">{profile.conditionSummary}</p></div><div className="rounded-xl border border-[#dfe9e5] bg-[#f1f8f5] p-3 text-[11px] leading-5 text-[#5b756c]"><span className="font-bold text-[#265a4e]">Selected care pathway:</span> {surgery.name}. The handoff is recorded in this showcase platform; a receiving-system integration must be configured before clinical deployment.</div><Button onClick={completeReferral} disabled={referralMutation.isPending} className="h-10 w-full rounded-full bg-[#0b746b] text-xs font-bold hover:bg-[#075d57]"><ClipboardCheck className="mr-2 h-4 w-4" />{referralMutation.isPending ? "Preparing handoff…" : "Prepare referral handoff"}</Button></div> : <div className="rounded-xl bg-amber-50 p-4 text-sm text-amber-800">No stored referral profile is available.</div>}</DialogContent></Dialog>
  </div>;
}
