import { Stethoscope, Settings2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function PortalSwitcher({ adminSurface = false }: { adminSurface?: boolean }) {
  const [location] = useLocation();
  const isAdmin = location.startsWith("/admin");
  const isDoctor = !isAdmin;

  const optionClass = (active: boolean) => cn(
    "inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-[11px] font-bold transition-colors sm:px-3.5",
    active ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
  );

  return (
    <nav
      aria-label="Portal switcher"
      className={cn(
        "fixed bottom-4 left-4 z-50 flex max-w-[calc(100vw-2rem)] items-center rounded-full border border-border bg-card p-1 shadow-lg",
        adminSurface && "md:left-[calc(var(--sidebar-width)+1rem)]",
      )}
    >
      <Link href="/#doctor-portal" className={optionClass(isDoctor)}>
        <Stethoscope className="h-3.5 w-3.5" />
        <span>Doctor portal</span>
      </Link>
      <Link href="/admin" className={optionClass(isAdmin)}>
        <Settings2 className="h-3.5 w-3.5" />
        <span>Administrator portal</span>
      </Link>
    </nav>
  );
}
